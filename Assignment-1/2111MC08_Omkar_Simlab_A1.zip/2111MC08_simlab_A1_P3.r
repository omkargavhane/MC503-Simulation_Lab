#P3
A=matrix(c(1.5,-1,-1,3),nrow=2)
x=c(4,7)
y=c(1,0)
c=matrix(c(A,x,y),nrow=2)
c

#output : 
#[omkar@gavhane Assignment]$ Rscript simlab_A1_P3.r 
#[,1] [,2] [,3] [,4]
#[1,]  1.5   -1    4    1
#[2,] -1.0    3    7    0