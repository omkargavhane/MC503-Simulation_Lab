i=2
j=4
x=i+(j-i+1)*runif(1000)
x
mean(x)
var(x)
