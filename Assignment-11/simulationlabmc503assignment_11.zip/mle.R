############## Exponential Distribution (lambda)
rm(list=ls(all=TRUE));
n=20
library(maxLik);
library(nleqslv);
## install.packages('maxLik')
lambda=1.2;
x <- (-1/lambda)*(log(1-runif(n)));
# LogLikelihood <- function(lmd){
	# (n*log(lmd))- (lmd*sum(x));
# }
# mle <- maxLik(logLik=LogLikelihood,start=1);
# mle;
mle_lmd <- numeric();
for(i in 1000){
mle_lmd <- n/sum(x);

est <- function(para){
	lmd <- para[1];
	mu <- para[2]
	eqns <- numeric()
	eqns[1] <- (n/lmd)-sum(x);
	eqns[2] <- ;
	return(eqns);
}
xstr <- c(1.2,mu1);
mle <- nleqslv(xstr, est,method='Newton',jacobian=TRUE);
mle_lmd[i] <- mle$x;
}
mean(mle_lmd);

mse <- (mle-lmd)^2;
bais <- mle-lambda;