
x=numeric(0)
n=5000

y1= numeric(0)
y2= numeric(0)
y3=numeric(0)
#generate sample
sample1 <- function(){
  for(i in 1:(n/2)){
    u1 = runif(1)
    x[i] <- u1
  }
  return(x)
}
x1 <- numeric()
sample2 <- function(){
  for(i in 1:(n/2)){
    u2 = runif(1)
    x1[i] <- u2
  }
  return(x1)
}

u1<-sample1()
u2<-sample2()

for (i in 1:(n/2)) 
{ 
  y1[i]=(-2*logb(u1[i],exp(1)))**0.5*cos(2*3.14*u2[i])
  y2[i]=(-2*logb(u1[i],exp(1)))**0.5*sin(2*3.14*u2[i])
}
#print(y1)
#print(y2)

y3<-c(y1,y2)

print(y3)

#mean and variance
mean(y3)
var(y3)