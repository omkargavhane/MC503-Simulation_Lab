fibonacci_number=function(no){
	fib_no=c(0,1)
	for(i in 1:(no-2))
		fib_no=append(fib_no,fib_no[length(fib_no)]+fib_no[length(fib_no)-1])
	return(fib_no)
}
fibonacci_number(10)
