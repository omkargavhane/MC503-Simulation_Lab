matrix_product=function(m1,m2){
  m1_nrow=nrow(m1)
  m1_ncol=ncol(m1)
  m2_nrow=nrow(m2)
  m2_ncol=ncol(m2)
  res=matrix(nrow=m1_nrow,ncol=m2_ncol)
  if(m1_ncol==m2_nrow){
    for(r in 1:m1_nrow)
      for(c in 1:m2_ncol)
        res[r,c]=vector_product(m1[r,],m2[,c])
    
    return(res)
  }
  return("Number of Rows & column mismatch!!")
}



mat_adjoint=function(A) {
  minor=function(A, i, j) 
    return(det(matrix(A[-i,-j])))
  
  cofactor=function(A, i, j) 
    return((-1)^(i+j) * minor(A,i,j))
  
  n=nrow(A)
  B=matrix(NA, n, n)
  print(B)
  for( i in 1:n )
    for( j in 1:n )
      B[i,j]=cofactor(A, i, j) 
  return(B)
}

A=matrix(c(1,-2,3,-1,3,-1,2,-5,5),nrow=3,ncol=3,byrow=TRUE)
print(A)
B=matrix(c(9,-6,17))
print(B)
#inverse_A=mat_adjoint(A)/det(A)
#x=matrix_product(inverse_A,B)

inverse=solve(A)
result=inverse%*%B
print(result)
