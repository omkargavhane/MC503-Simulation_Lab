sx <- sample(x=c(0,1),size=100,replace=TRUE,prob=c(0.5,0.5))
sx
length(sx[sx==0])
length(sx[sx==1])